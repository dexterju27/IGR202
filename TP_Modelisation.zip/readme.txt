Informatique Graphique 3D et R�alit� Virtuelle 

Travaux Pratique

Traitement G�om�trique


Compilation : cd src; make -f Makefile.linux

Remplacer linux par cygwin pour une installation sous Linux/Cygwin

Execution : ./main models/<fichier.off>

Contact: Tamy Boubekeur (tamy.boubekeur@telecom-paristech.fr)